package adam.service;

import java.util.List;

import org.hibernate.dialect.MySQL5Dialect;

import adam.entity.EmployeeEntity;


public interface EmployeeManager {
	
	public void addEmployee(EmployeeEntity employee);
    public List<EmployeeEntity> getAllEmployees();
    public void deleteEmployee(Integer employeeId);
}
